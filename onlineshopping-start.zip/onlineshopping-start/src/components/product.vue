<template>
<div>
    <h2>{{productdetails.title }}</h2>
    
    <img :src="productdetails.ImageUrl" height="200px" width="200px" /><br />

    <b>Price : </b>{{productdetails.price }} <br />

    <b>Rating : </b>{{productdetails.rating }} <br />
    <b>Quantity : </b>{{productdetails.quantity }}<br />

    <button >
        <span>
        </span>
        {{productdetails.likes}}
    </button>
</div>
</template>

<script>
export default {
    name: 'Product',
    props: {
        productdetails: Object
    },
    data() {

    }
}
</script>

<style scoped>

</style>
