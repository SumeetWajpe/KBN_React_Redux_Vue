import axios from "axios";
const INCREMENT_LIKES = "INCREMENT_LIKES";
const DELETE_PRODUCT = "DELETE_PRODUCT";
const ADD_PRODUCT = "ADD_PRODUCT";
const DELETE_POST = "DELETE_POST";

export function IncrementLikes(theId) {
  return { type: INCREMENT_LIKES, theId };
}
export function DeleteProduct(theId) {
  return { type: DELETE_PRODUCT, theId };
}
export function AddProduct() {
  return { type: ADD_PRODUCT };
}
export function DeletePost(theId) {
  return { type: DELETE_POST,theId };
}

export function FetchAllPosts(data) {
  return { type: "FETCH_ALL_POSTS", data };
}
export function FetchAllPostsAsync() {
  return (dispatch) => {
    var thePromise = axios.get("https://jsonplaceholder.typicode.com/posts");
    thePromise.then(
      (response) => dispatch(FetchAllPosts(response.data)),
      (err) => console.log(err)
    );
  };
}
