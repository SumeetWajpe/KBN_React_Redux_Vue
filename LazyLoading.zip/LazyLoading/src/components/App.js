import React , {lazy,Suspense} from 'react';
import logo from './logo.svg';
import './App.css';
import ListOfProducts from './listofproducts.component';
import { BrowserRouter, Link, Switch, Route, Redirect } from 'react-router-dom';
// import PostsComponent from './posts.component';
import PostDetails from './postdetails.component';
// import AddNewProductComponent from './addnewproduct.component';
const AddNewProductComponent = lazy(()=> import("./addnewproduct.component"));
const PostsComponent = lazy(()=> import('./posts.component'));

const loader = () => <strong>Loading..</strong>
export const PostsContext = React.createContext([]);

function App(props) {  
  return (
    <BrowserRouter>    
    <nav className="navbar navbar-inverse">
        <div className="container-fluid">
          <div className="navbar-header">
            <Link className="navbar-brand" to="/">
              Online Shopping
            </Link>
          </div>
          <ul className="nav navbar-nav">
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/posts">Posts</Link>
            </li>
            <li>
              <Link to="/newproduct">New Product</Link>
            </li>                     
          </ul>
        </div>
      </nav>
    <Switch>
        <Route path="/" exact render={(routeprops)=> <ListOfProducts {...routeprops} {...props} />}></Route>
        <Route path="/posts" exact render={(routeprops)=>(
           <Suspense fallback={loader()}>
             <PostsComponent {...routeprops} {...props} />}  >
           </Suspense>
        )}>
           </Route>
        <Route path="/postdetails/:id" exact render={(routeprops)=>
        (
            <PostsContext.Provider value={{allposts:props.allposts,DeletePost:props.DeletePost}}>
              <PostDetails {...routeprops} />
            </PostsContext.Provider>
        )}>
             
           </Route>
        <Route path="/newproduct" exact render={(routeprops)=> (
          <Suspense fallback={loader()}>
              <AddNewProductComponent {...routeprops} {...props} />
          </Suspense>
       )}></Route>
        <Route path="**" render={() => <Redirect to="/" />}></Route>
      </Switch>
    </BrowserRouter>
            
  );
}

export default App;
