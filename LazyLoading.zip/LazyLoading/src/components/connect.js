import {connect} from 'react-redux';
import * as AllActions from '../actions/actioncreators';
import { bindActionCreators } from 'redux';
import App from './App';

function mapStateToProps(storeData){  
        return{
            allproducts:storeData.products,
            allposts:storeData.posts
        }
    }

function mapDispatchToProps(dispatcherObj){
        return bindActionCreators(AllActions,dispatcherObj);
}
var HOCApp = connect(mapStateToProps,mapDispatchToProps)(App);
export default HOCApp;

