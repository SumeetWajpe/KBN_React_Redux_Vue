var theIndex;
export function products(defStore=[{"id":1,"name":"Mobile","price":25000,"rating":3,"quantity":100,"likes":300,"imageUrl":"https://www.91-img.com/pictures/133188-v4-oppo-f11-mobile-phone-large-1.jpg"},{"id":2,"name":"LED TV","price":30000,"rating":4,"quantity":200,"likes":400,"imageUrl":"https://cdn1.smartprix.com/rx-i5aBE1MKX-w1200-h1200/haier-le32k6000b-32.jpg"},{"id":3,"name":"LCD TV","price":40000,"rating":4,"quantity":500,"likes":200,"imageUrl":"https://cdn1.smartprix.com/rx-i5aBE1MKX-w1200-h1200/haier-le32k6000b-32.jpg"},{"id":4,"name":"OLED TV","price":70000,"rating":5,"quantity":400,"likes":400,"imageUrl":"https://images-na.ssl-images-amazon.com/images/I/81I3YUc5eqL._AC_SL1500_.jpg"},{"id":5,"name":"DSLR","price":100000,"rating":5,"quantity":600,"likes":200,"imageUrl":"https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_front.png"}] , action) {
  switch (action.type) {
    case "INCREMENT_LIKES":
      console.log("Within Products Reducer :: INCREMENT_LIKES");
      theIndex = defStore.findIndex((p) => p.id == action.theId);

      return [
        ...defStore.slice(0, theIndex),
        { ...defStore[theIndex], likes: defStore[theIndex].likes + 1 },
        ...defStore.slice(theIndex + 1)
      ]; // new Store
    case "DELETE_PRODUCT":
      theIndex = defStore.findIndex((p) => p.id == action.theId);

      return [...defStore.slice(0, theIndex), ...defStore.slice(theIndex + 1)]; // new Store
    default:
      return defStore;
  }
}
