import React from 'react';
import logo from './logo.svg';
import './App.css';
import Product from './product.component';
import ProductModel from './product.model';

//import Msg,{Addition} from './message.component';
// import * as Everything from './message.component';


class App extends React.Component {

  render() {
    // var productsList =[
    //   {name:"Laptop", price:50000},
    //  {name:"LED TV", price:30000},
    //  {name:"LCD TV", price:40000}
    // ];   
    // OR

    var productsList = [
      new ProductModel("Mobile", 25000, 3, 100, 300, "https://www.91-img.com/pictures/133188-v4-oppo-f11-mobile-phone-large-1.jpg"),
      new ProductModel("LED TV", 30000, 4, 200, 400, "https://cdn1.smartprix.com/rx-i5aBE1MKX-w1200-h1200/haier-le32k6000b-32.jpg"),
      new ProductModel("LCD TV", 40000, 4, 500, 200, "https://cdn1.smartprix.com/rx-i5aBE1MKX-w1200-h1200/haier-le32k6000b-32.jpg"),
      new ProductModel("OLED TV", 70000, 5, 400, 400, "https://images-na.ssl-images-amazon.com/images/I/81I3YUc5eqL._AC_SL1500_.jpg"),
      new ProductModel("DSLR", 100000, 5, 600, 200, "https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_front.png"),
    ];
    var productsToBeDisplayed = productsList.map(
      p => <Product productdetails={p} />
    );
    return <div>
      <div className="jumbotron">
        <h1> Online Shopping</h1>
      </div>
      <div className="row">
        {productsToBeDisplayed}

      </div>
    </div>
  }
}
export default App;


// class App extends React.Component {
//   render() {
//     return <div>      
//       <Message msg="Hello" to="Mr.Sumeet" />
//      <Message msg="Hi" to="Mr.Amit"  />
//      <Message msg="Hola" to="Mr.Aniket" />
//      <Message msg="Bye" to="Mr.Ram" />
//      <Message />
//     </div>
//   }
// }
// export default App;