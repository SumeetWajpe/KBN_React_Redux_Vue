import React from 'react';

export default class Product extends React.Component {
    constructor(props){
        super(props);
        this.state = {count:this.props.productdetails.likes};
    }
    IncrementLikesHandler(){
        console.log('Inside IncrementLikesHandler');
        //this.props.productdetails.likes+=1; // props are readonly !

        //this.state.count+=1; // state is immutable !
        this.setState({count:this.state.count+1});

        // React updates UI  -> a new set of props | state changes !
        // State -> 1. Private for a component
                    // -> 2. Every component has its own state !
    }
    render() {
        return <div className="col-md-4">
            <div className="ProductStyle">
                <h1>{this.props.productdetails.name}</h1>
                <img src={this.props.productdetails.imageUrl}
                    height="200px" width="200px" />
                <h5>Price : {this.props.productdetails.price}</h5>
                <h5>Rating : {this.props.productdetails.rating}</h5>
                <h5>Quantity : {this.props.productdetails.quantity}</h5>
                <button className="btn btn-primary" 
                 onClick={this.IncrementLikesHandler.bind(this)}
                //  onClick={()=>this.IncrementLikesHandler()}
                >
                    <span className="glyphicon glyphicon-thumbs-up">
                    </span>
                    {this.state.count}
                </button>
            </div>
        </div>
    }
}