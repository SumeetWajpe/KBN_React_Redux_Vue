import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

export const store = new Vuex.Store({
    state:{
        counter:0
    },
    getters:{
        doubleTheCounter:state =>{
            return state.counter * 2;
        }
    },
    mutations:{
        incrementcount:(state,payload)=>{
            state.counter+=payload;
        },
        decrementcount:(state,payload)=>{
            state.counter= state.counter - payload;
        }
    },
    actions:{
        increment: ({commit},payload) =>{
            commit('incrementcount',payload);
        },
        decrement: ({commit},payload) =>{
            commit('decrementcount',payload);
        }
    }
})