<template>
    <div>
        <button class="btn btn-primary" @click="increment(50)">Increment</button>
        <button class="btn btn-primary" @click="decrement(50)">Decrement</button>
    </div>
</template>

<script>
import { mapActions } from 'vuex'
    export default {
       methods:{
           ...mapActions([
               'increment',
               'decrement'
           ]),
           increment(incrementBy){
               this.$store.dispatch('increment',incrementBy);
           }
       }
    }
</script>