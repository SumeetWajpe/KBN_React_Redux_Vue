<template>
    <p>Counter is: {{ doubleTheCounter }}</p>
</template>
<script>
import {mapGetters} from 'vuex';
    export default {
        computed:{           
            ...mapGetters([
            'doubleTheCounter'
        ])
        }
    }
</script>