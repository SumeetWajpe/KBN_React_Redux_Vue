<template>
<div>
    <h1>List of Courses - Coursera</h1>
    Is Online ? <input type="checkbox" v-model="isOnline" /> <br />

   <input type="button" dark value="Add New Course" @click="courses.push('Typescript')" /> <br/>

    Search Here : <input type="text" v-model="filterText" />    <ul>
        <li v-for="course in filteredCourses" :key="course">{{course}}</li>
    </ul>
</div>
</template>
<script>
import {courseMixin} from '../courseMixin';
export default {
    name: 'udemy',
    mixins: [courseMixin],
    data() {
        return {
            // courses:[".NET","C#","LINQ"],
            isOnline: true
        }
    }
}
</script>

<style scoped>

</style>
