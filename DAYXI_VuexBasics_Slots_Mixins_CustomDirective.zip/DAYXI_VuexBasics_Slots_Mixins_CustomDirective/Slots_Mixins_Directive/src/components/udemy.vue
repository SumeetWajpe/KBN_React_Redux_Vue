<template>
    <div>
        <h1>List of Courses - Udemy</h1>
        <input type="text" v-model="filterText" />
        <ul>
            <li v-for="course in filteredCourses" :key="course">{{course}}</li>
        </ul>
    </div>
</template>

<script>
import {courseMixin} from '../courseMixin';

    export default {
        name:'udemy',
        mixins:[courseMixin]
       
    }
</script>

<style scoped>

</style>