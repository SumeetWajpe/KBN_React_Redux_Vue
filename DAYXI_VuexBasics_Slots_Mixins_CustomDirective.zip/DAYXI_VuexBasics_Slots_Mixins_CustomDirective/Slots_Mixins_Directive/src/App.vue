<template>
  <v-app>
    <v-app-bar
      app
      color="amber"
      dark
    >
      <div class="d-flex align-center">
        <v-img
          alt="Vuetify Logo"
          class="shrink mr-2"
          contain
          src="https://pngimg.com/uploads/shopping_cart/shopping_cart_PNG38.png"
          transition="scale-transition"
          width="40"
        />

       <h1 class="display-2 text-uppercase"><span class="font-weight-light">Online </span> Shopping</h1>
      </div>
      <v-spacer></v-spacer>

      <v-btn class="mx-3  white--text">
        <router-link to="/">Home</router-link>
      </v-btn>
      
      <v-btn class="mx-3  white--text">
        <router-link to="/posts">Posts</router-link>
      </v-btn>
       <v-btn class="mx-3  white--text">
        <router-link to="/courses">Courses</router-link>
      </v-btn>

      <v-spacer></v-spacer>

      <v-btn
        href="https://github.com/vuetifyjs/vuetify/releases/latest"
        target="_blank"
        text
      >
        <span class="mr-2">Latest Release</span>
        <v-icon>mdi-open-in-new</v-icon>
      </v-btn>
    </v-app-bar>

    <v-content>
      <v-container>
        <router-view></router-view>
      </v-container>
    </v-content>
  </v-app>
</template>

<script>
//import ShoppingCart from './components/shoppingcart';

export default {
  name: 'App',

  components: {
    // ShoppingCart,
  },

  data: () => ({
    //
  }),
};
</script>
