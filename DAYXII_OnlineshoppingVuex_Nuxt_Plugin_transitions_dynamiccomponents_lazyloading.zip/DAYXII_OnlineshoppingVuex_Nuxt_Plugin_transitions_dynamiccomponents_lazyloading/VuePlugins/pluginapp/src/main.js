import Vue from 'vue'
import App from './App.vue'
import {windowPlugin} from './scrollplugin';

Vue.config.productionTip = false

Vue.use(windowPlugin);

Vue.component('my-component',{
  template:`<div style="size:100;position:fixed;background-color:grey">
  {{scrollY}}
  </div>`,
  computed:{
    scrollY:function(){
      return this.$window.scrollY;
    }
  }
})

new Vue({
  render: h => h(App),
}).$mount('#app')
