
export var windowPlugin = {
    install:function(Vue){
      var cdata = new Vue({
        data:{
          scrollY:0
        }
      })
  
      var timer = null;
      window.addEventListener('scroll',function(){
        timer = setTimeout(function(){
          cdata.scrollY = window.scrollY;
          clearTimeout(timer);
          timer = null
        },1000)
      })
      Vue.prototype.$window = cdata.$data;
    }
  }
  