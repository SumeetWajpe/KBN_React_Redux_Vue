import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';

Vue.use(Vuex);

export const store = new Vuex.Store({
    state:{
        products:[]
    },
    getters:{
        // state.products
        getAllProducts:state=>{
            return state.products
        }
    },
    mutations:{
        // state.products = response
        returnallProducts:(state,payload)=>{
            state.products = payload;
        },
        incrementlikes:(state,payload)=>{
            let index = state.products.findIndex(p=>p.id == payload);
            state.products[index].likes++;
        },
        deleteproduct:(state,payload)=>{
            let index = state.products.findIndex(p=>p.id == payload);
            state.products.splice(index,1);
        }
    },
    actions:{
       // axios 
       fetchProducts:({commit})=>{
        axios.get('./products.json').then(
            (response)=>commit('returnallProducts',response.data),
            (err)=>console.log(err)
        )
       },incrementlikes:({commit},payload)=>{
           commit('incrementlikes',payload);
       },
       deleteproduct:({commit},payload)=>{
        commit('deleteproduct',payload);
    },
    }
})