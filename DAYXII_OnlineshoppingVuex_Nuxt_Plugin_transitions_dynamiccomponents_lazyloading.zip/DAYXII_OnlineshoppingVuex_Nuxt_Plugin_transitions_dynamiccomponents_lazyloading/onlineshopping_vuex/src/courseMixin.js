export const courseMixin = {
    data(){
        return {
            courses:['HTML5','React','Angular','Vue'],
            filterText:''
        }
    },
    computed:{
        filteredCourses(){
            return this.courses.filter(c=>c.match(this.filterText))
        }
    }
}