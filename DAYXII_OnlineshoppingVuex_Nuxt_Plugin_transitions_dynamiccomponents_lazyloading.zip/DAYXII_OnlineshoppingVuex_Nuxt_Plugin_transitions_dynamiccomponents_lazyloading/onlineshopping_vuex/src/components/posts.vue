<template>
   <transition name="slide-fade">
   
    <div>
        <h1 class="display-2">All Posts</h1>
        <v-alert
      border="left"
      colored-border
      color="green"     
      elevation="2"
      v-for="post in allposts"
      :key="post.id"
    >
     <!-- <router-link to="`/postdetails/${}`"> {{post.title}} </router-link> -->
     <router-link :to="{ name:'postdetails' , params:{id: post.id}}"> {{post.title}} </router-link>

    </v-alert>
    </div>
    </transition>
</template>

<script>
import axios from 'axios';

    export default {
        name :'Posts',
        data(){
            return {
                allposts:[]
            }
        },
        mounted(){
             axios.get('https://jsonplaceholder.typicode.com/posts')   
             .then(response=> this.allposts = response.data)
        }

    }
</script>

<style scoped>
.slide-fade-enter-active {
  transition: all .3s ease;
}
.slide-fade-leave-active {
  transition: all .8s cubic-bezier(1.0, 0.5, 0.8, 1.0);
}
.slide-fade-enter, .slide-fade-leave-to
/* .slide-fade-leave-active below version 2.1.8 */ {
  transform: translateX(10px);
  opacity: 0;
}
</style>