<template>
<div>
    <v-btn color="primary white--text" @click="componentToBeCreated='signin'">
        Sign In
    </v-btn>
    <v-btn color="primary white--text" @click="componentToBeCreated='signup'">
        Sign Up
    </v-btn>
    <keep-alive>
        <transition name="bounce">
            <component :is="componentToBeCreated">
            </component>
        </transition>
    </keep-alive>
</div>
</template>

<script>
import SignIn from './signin';
import SignUp from './signup';
export default {
    components: {
        'signup': SignUp,
        'signin': SignIn
    },
    data() {
        return {
            componentToBeCreated: 'signin'
        }
    }
}
</script>

<style scoped>
.bounce-enter-active {
  animation: bounce-in .3s;
}
.bounce-leave-active {
  animation: bounce-in .3s reverse;
}
@keyframes bounce-in {
  0% {
    transform: scale(0);
  }
  50% {
    transform: scale(1.2);
  }
  100% {
    transform: scale(1);
  }
}
</style>
