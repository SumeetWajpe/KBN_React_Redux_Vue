<template>
<v-card class="mx-auto" max-width="400" :class="isSelected ? 'success lighten-5' : '' ">
    <!-- <v-card-title class="display-1">{{productdetails.title }}</v-card-title> -->
    <!-- <slot>
        <strong> Product Name goes here.. </strong>
    </slot> -->
    <slot name="header" 
    v-bind:pd="productdetails">
        
    </slot>
    <v-divider></v-divider>
    <slot name="maincontent"
    v-bind:productdetails="productdetails">
    </slot>
    <v-divider></v-divider>

    <v-card-actions>
        <v-btn color="indigo" dark fab @click="IncrementLikes(productdetails.id)">
            <v-icon>mdi-thumb-up</v-icon>
        </v-btn>
        <v-btn color="red" dark outlined 
         fab @click="DeleteProduct(productdetails.id)">
            <v-icon>mdi-delete</v-icon>
        </v-btn>
        <v-switch
        class="mx-4"
      v-model="isSelected"
      label="Add to cart"
      :disabled="!productdetails.quantity"
    ></v-switch>
    </v-card-actions>
</v-card>
</template>

<script>
export default {
    name: 'Product',
    props: {
        productdetails: Object
    },
    data() {
        return{
            isSelected:false
        }
    },
    filters:{
        currency(val,args){
            return `${args}${val}`
        }
    },
    methods:{
        IncrementLikes(theId){
            this.$store.dispatch('incrementlikes',theId);
        },
        DeleteProduct(theId){
            this.$store.dispatch('deleteproduct',theId);
            
        }
    }
}
</script>

<style scoped>

</style>
