<template>
    <div  style="background-color:lightgreen;border:2px solid gray;border-radius:10px;margin:10px;padding:10px">
        <h1> Post Details for {{postid}} </h1>
        <hr/>
        <div>
            <strong>
                Post Id : 
            </strong> {{thePost.id}} <br/>
             <strong>
                Post User Id : 
            </strong> {{thePost.userId}} <br/>
             <strong>
                Post Title : 
            </strong> {{thePost.title}} <br/>
             <strong>
                Post Body : 
            </strong> {{thePost.body}} <br/>
        </div>
    </div>
</template>

<script>
import axios from 'axios';

    export default {
        name:'PostDetails',
        data(){
            return{
                postid: this.$route.params.id,
                thePost:{}
            }
        },
        mounted(){
             axios.get('https://jsonplaceholder.typicode.com/posts/'+this.postid)   
             .then(response=> this.thePost = response.data)
        }
    }
</script>

<style scoped>

</style>