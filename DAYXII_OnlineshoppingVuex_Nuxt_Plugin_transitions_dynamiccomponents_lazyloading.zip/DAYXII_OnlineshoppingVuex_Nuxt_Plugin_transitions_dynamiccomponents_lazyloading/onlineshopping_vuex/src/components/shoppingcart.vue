<template>
<div>
    <v-row>
        <v-col v-for="product in $store.state.products" cols="12" sm="4" :key="product.id">
            <Product :productdetails="product">
                <!-- h2 maps to default slots -->
                <!-- <h2>Overiding Product Name</h2> -->
                <template v-slot:header="proddetails">
                    <v-card-title class="display-1">{{proddetails.pd.title }}</v-card-title>
                    <!-- <span>{{product.title}}</span> -->
                </template>
                <template v-slot:maincontent="proddetails">
                    <v-img class="white--text align-end" :style="proddetails.productdetails.quantity ? '' : {opacity:0.3}" height="250px" width="350px" :src="proddetails.productdetails.ImageUrl">
                    </v-img>
                    <v-card-subtitle v-if="proddetails.productdetails.quantity" class="pb-0 green--text">Available</v-card-subtitle>
                    <v-card-subtitle v-if="!proddetails.productdetails.quantity" class="pb-0 red--text">Unavailable</v-card-subtitle>

                    <v-card-text class="text--primary subtitle-1">
                        <div v-highlight:background.delayed="{maincolor:'lightgreen',delayby:1000}"><b>Price : </b>{{proddetails.productdetails.price }} </div>
                        <div><b>Rating : </b>{{proddetails.productdetails.rating }} </div>
                        <div><b>Quantity : </b>{{proddetails.productdetails.quantity | outofstock('nos') }} </div>
                        <div><b>Likes : </b>{{proddetails.productdetails.likes }} </div>
                    </v-card-text>
                </template>
            </Product>
        </v-col>
    </v-row>
</div>
</template>

<script>
import Product from './product.vue';
import {mapActions} from 'vuex';

export default {
    name: 'ShoppingCart',
    components: {
        Product
    },
    data() {
        return {
            products: []
        }

    },
    mounted(){
        this.$store.dispatch('fetchProducts')
    },
    methods: {
        ...mapActions(['fetchProducts'])       
    },
    // directives:{
    //     'local-highlight':{
    //         bind(){

    //         }
    //     }
    // }
}
</script>

<style scoped>

</style>
