<template>
<div>
        <Udemy></Udemy>
        <Coursera></Coursera>
</div>
</template>

<script>
import Udemy from './udemy';
import Coursera from './coursera';

export default {
    name: 'Course',
    components:{
        Udemy,
        Coursera
    }
    
   
}
</script>

<style scoped>
   
</style>
