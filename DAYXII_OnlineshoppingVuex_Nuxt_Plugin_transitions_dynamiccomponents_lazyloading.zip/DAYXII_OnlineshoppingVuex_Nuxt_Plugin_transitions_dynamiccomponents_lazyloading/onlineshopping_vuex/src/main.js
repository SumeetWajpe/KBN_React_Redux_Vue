import Vue from 'vue'
import App from './App.vue'
import vuetify from './plugins/vuetify';
import VueRouter from 'vue-router';
import ShoppingCart from './components/shoppingcart';
// import Posts from './components/posts';
import PostDetails from './components/postdetails';
import Course from './components/course.component';
import {store} from './store/store';
import DynamicComponent from './components/dynamiccomponent';// static import ! webpack 

const Posts = () => import('./components/posts'); // lazy loading !

Vue.config.productionTip = false


Vue.use(VueRouter);
const routes = [
  {path:'/',component:ShoppingCart},
  {path:'/posts',component:Posts},
  {path:'/postdetails/:id',component:PostDetails,name:'postdetails'},
  {path:'/courses',component:Course},
  {path:'/login',component:DynamicComponent},



];
var router = new VueRouter({
  routes,
  mode:'history'  
});

// Global Mixin
// Vue.mixin({

// })

Vue.directive('highlight',{
  bind(el,binding){ // bind is called when directive gets attached to the element      
    if(binding.modifiers['delayed']){
      setTimeout(()=>{
        if(binding.arg == "background"){      
          
          el.style.backgroundColor = binding.value.maincolor;      
        }
        else{
          el.style.border = '2px solid ' + binding.value.maincolor;
        }
      },binding.value.delayby)
    }
    
  }
})


Vue.filter('outofstock',function(val,args){
    switch(val){
      case 0:
        return 'OUT OF STOCK !';
        case 1:
          return val + " " + args.substring(0,args.length-1);
        default:
          return val + " " + args
    }
});

new Vue({
  vuetify,
  router,
  store,
  render: h => h(App)
}).$mount('#app')
