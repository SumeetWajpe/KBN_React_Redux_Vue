import React from 'react';
import logo from './logo.svg';
import './App.css';

import ListOfProducts from './listofproducts.component';
import PostsComponent from './posts.component';
import FunctionalComponent from './functional.component';

//import Msg,{Addition} from './message.component';
// import * as Everything from './message.component';

// Functional Component
// 1. No render()
// 2. No State
//3. No LifeCycleHooks
//4. No setState()

function App(){ 
     return <FunctionalComponent message="Hello From Props" />    
}
export default App;

// class App extends React.Component {
//   render() {
//     return <div>      
//       <Message msg="Hello" to="Mr.Sumeet" />
//      <Message msg="Hi" to="Mr.Amit"  />
//      <Message msg="Hola" to="Mr.Aniket" />
//      <Message msg="Bye" to="Mr.Ram" />
//      <Message />
//     </div>
//   }
// }
// export default App;