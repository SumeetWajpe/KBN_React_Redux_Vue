import React from 'react';

export default class Message extends React.Component{
    render(){
    return <h1 className="HeaderStyle">Wishing {this.props.msg} to {this.props.to} !</h1>
    }
}
Message.defaultProps = {
    msg:'Hi',
    to:'Everyone'
}

export function Addition(x,y){
    return x + y;
}

export function Product(x,y){
    return x * y;
}

