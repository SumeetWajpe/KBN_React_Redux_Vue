import React from 'react';
import App from './App';
import Enzyme,{shallow} from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('test suite for app component',()=>{
    it('should start with state equal to 0',()=>{
      // instance of app component
      // state -> 0
      var appInstance = shallow(<App/>); // use Enzyme's renderer to generate DOM (in memory)
      var count = appInstance.state().count;
      expect(count).toBe(0);
    });

    it('should increment the count on click',()=>{
        var appInstance = shallow(<App/>);
        var btn = appInstance.find('button');
        btn.simulate('click');
        var pText = appInstance.find('p').text();
         expect(pText).toEqual('Count : 1');
    });
});







// Angular => jasmine + karma
// TestBed => Angular specific API

// React  => JEST
// Enzyme => React specific API