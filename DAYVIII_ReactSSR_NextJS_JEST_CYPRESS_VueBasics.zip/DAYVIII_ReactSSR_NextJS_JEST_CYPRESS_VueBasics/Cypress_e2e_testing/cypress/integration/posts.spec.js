describe('Posts and post details testing',()=>{
    
    it('should generate 100 list items',()=>{
        cy.visit('http://localhost:3000/posts');
     
        cy.get('ul li').as('list');

        cy.get('@list').its('length').should('be.eq',100);

        cy.get('@list').first().click();
        cy.url().should('eq','http://localhost:3000/postdetails/1');
    });

    it('should navigate to postdetails with click on post item ',()=>{
        cy.visit('http://localhost:3000/posts');
       
    });
})