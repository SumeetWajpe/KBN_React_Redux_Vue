describe('Heading Text',()=>{
    it('contains h1 title to be Online Shopping',()=>{
        cy.visit('http://localhost:3000');

        cy.get('h1')
            .invoke('text')
            .should('equal','Online Shopping'); 
    });
    it('test increment count',()=>{
        cy.visit('http://localhost:3000');
        cy.get('button').first().click().should('have.text','101')

    });

})