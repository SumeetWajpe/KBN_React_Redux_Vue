import React from 'react';
import logo from './logo.svg';
import './App.css';
import Message from './message';

function App() {
  return (
    <div className="App">
      <Message msg="This is React SSR !" />
    </div>
  );
}

export default App;
