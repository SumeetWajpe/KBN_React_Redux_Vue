import React from 'react';

export default props =>{
    return <h1>{props.msg}</h1>
}