import React, { useState } from 'react';
//useState 16.8 feature

// this.state = {count:0,age:18}

export const Counter = (props) => {
    var [count,setCount] = useState(0);    
    var [age,setAge]  = useState(18);
    return(
        <div>
            <p>U Clicked : {count} times !</p>
           <button className="btn btn-primary"
           onClick={()=>setCount(count+1)}>
                Increment Count
           </button>
           <hr/>
           <p>Age : {age} !</p>
           <button className="btn btn-primary"
           onClick={()=>setAge(age+10)}>
                Increment Age
           </button>
        </div>
    )
}

export default Counter;