import React from "react";
import logo from "./logo.svg";
import "./App.css";

import ListOfProducts from "./listofproducts.component";
import PostsComponent from "./posts.component";
import FunctionalComponent from "./functional.component";
import Counter from "./usestatehook.component";
import AddNewProductComponent from "./addnewproduct.component";
import UseEffectComponent from "./useeffecthook.component";
import { BrowserRouter, Route, Redirect, Switch, Link } from "react-router-dom";
import PostDetails from "./postdetails.component";

//import Msg,{Addition} from './message.component';
// import * as Everything from './message.component';

// Functional Component
// 1. No render()
// 2. No State
//3. No LifeCycleHooks
//4. No setState()

// function App() {
// return <FunctionalComponent message="Hello From Props" />
// return <Counter />
//   return  <React.Fragment>
{
  /* <AddNewProductComponent />
               <ListOfProducts /> */
}
{
  /* <UseEffectComponent /> */
}
{
  /* </React.Fragment>; */
}
// }

// Set of Routes
// 1. path -> /    =>   Component =  ListOfProducts
// 2. path -> /posts => Component = PostsComponent
// 3. path -> /newProduct  => COmponent = AddNewProduct

function App() {
  return (
    <BrowserRouter>
      <nav className="navbar navbar-inverse">
        <div className="container-fluid">
          <div className="navbar-header">
            <Link className="navbar-brand" to="/">
              Online Shopping
            </Link>
          </div>
          <ul className="nav navbar-nav">
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/posts">Posts</Link>
            </li>
            <li>
              <Link to="/newproduct">Add New Product</Link>
            </li>
          </ul>
        </div>
      </nav>

      <Switch>
        <Route path="/" exact component={ListOfProducts}></Route>
        <Route path="/posts" exact component={PostsComponent}></Route>
        <Route path="/postdetails/:id" exact component={PostDetails}></Route>
        <Route path="/newproduct" exact component={AddNewProductComponent}></Route>
        {/* <Route path="**" component={ErrorComponent}></Route> */}
        {/* <Route path="**" render={()=><h1 style={{color:'red'}}>404 !Page Not found !</h1>}></Route> */}
        <Route path="**" render={() => <Redirect to="/" />}></Route>
      </Switch>
    </BrowserRouter>
  );
}
export default App;

// class App extends React.Component {
//   render() {
//     return <div>
//       <Message msg="Hello" to="Mr.Sumeet" />
//      <Message msg="Hi" to="Mr.Amit"  />
//      <Message msg="Hola" to="Mr.Aniket" />
//      <Message msg="Bye" to="Mr.Ram" />
//      <Message />
//     </div>
//   }
// }
// export default App;

// Functional                      Class
// useEffect()           ->         LifeCycle
// useState()            ->          State
