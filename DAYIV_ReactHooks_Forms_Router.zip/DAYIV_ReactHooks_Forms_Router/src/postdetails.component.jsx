import React, { useEffect, useState } from "react";
import axios from 'axios';

export const PostDetails = (props) => {
    console.log(props);
    const [singlepost,setSinglePost] = useState({});
    useEffect(()=>{
        let thePromise = axios.get('https://jsonplaceholder.typicode.com/posts/'+params.id);
        thePromise.then(
            (response)=>{
               setSinglePost(response.data); 
            },(err)=>{
                console.log(err);
            }
        );
    },[])

    const {match:{params}} = props;
    
    return(
        <div>
            <div className="jumbotron">
                <h1> Post Details </h1>               
            </div>   
                <h3>Id : { singlepost.id}</h3>
                <h3>User Id : { singlepost.userId}</h3>
                <h3>Title : { singlepost.title}</h3>
                <h3>Body : { singlepost.body}</h3>         
        </div>
    )
}

export default PostDetails;