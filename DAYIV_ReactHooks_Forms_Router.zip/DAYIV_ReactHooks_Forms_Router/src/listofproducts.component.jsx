import React from 'react';
import ProductModel from './product.model';
import Product from './product.component';

// container | Parent
// presentational 

export default class ListOfProducts extends React.Component {
 // mounting , updating , unmounting
    constructor(props) {
        super(props);
        //console.log('Within constructor !');

        this.state = {
            productsList: [
                new ProductModel(1,"Mobile", 25000, 3, 100, 300, "https://www.91-img.com/pictures/133188-v4-oppo-f11-mobile-phone-large-1.jpg"),
                new ProductModel(2,"LED TV", 30000, 4, 200, 400, "https://cdn1.smartprix.com/rx-i5aBE1MKX-w1200-h1200/haier-le32k6000b-32.jpg"),
                new ProductModel(3,"LCD TV", 40000, 4, 500, 200, "https://cdn1.smartprix.com/rx-i5aBE1MKX-w1200-h1200/haier-le32k6000b-32.jpg"),
                new ProductModel(4,"OLED TV", 70000, 5, 400, 400, "https://images-na.ssl-images-amazon.com/images/I/81I3YUc5eqL._AC_SL1500_.jpg"),
                new ProductModel(5,"DSLR", 100000, 5, 600, 200, "https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_front.png"),
            ]

        }
    }

    componentWillMount(){
        // Initialization logic
        //console.log('Within componentWillMount !');
    }
    componentDidMount(){
        // DOM is ready !
        // setTimeout()
        // ajax()
        //console.log('Within componentDidMount !');
    }

    shouldComponentUpdate(){
        // console.log('Within shouldComponentUpdate !');
        // console.log('Args ->')
        // console.log(arguments);
        // console.log('shouldComponentUpdate :  State ->');
        // console.log(this.state);
        return true;
    }    
    componentWillUpdate(){
        //console.log('Within componentWillUpdate !');
       // console.log(this.state);
    }

    componentDidUpdate(){
        //console.log('Within componentDidUpdate !');
    }

    DeleteHandlerFromParent(theId){
        //console.log('Within DeleteHandlerFromParent :: ListOfProducts ' + theId);
        // biz logic //?
        let newProductList = this.state.productsList.filter(p=>p.id !== theId);
        this.setState({productsList:newProductList});
        //console.log('DeleteHandlerFromParent :  State ->');
        //console.log(this.state);
    }
    render() {
        //console.log('Within render');
        //console.log(this.state);
        var productsToBeDisplayed = this.state.productsList.map(
            p => <Product productdetails={p} 
            key={p.id}
            DeleteHandler={(theId)=>this.DeleteHandlerFromParent(theId)} />
        );
        return <div>
            <div className="jumbotron">
                <h1> Online Shopping</h1>
            </div>
            <div className="row">
                {productsToBeDisplayed}
            </div>
        </div>
    }
}