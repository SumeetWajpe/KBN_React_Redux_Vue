import React, { useState, useEffect } from 'react';
import axios from 'axios';  

export const UseEffectComponent = (props) => {
    const [postList, setPostsList] = useState([]); 
    useEffect(() => {
        console.log('Calling API !')
        let thePromise = axios.get('https://jsonplaceholder.typicode.com/posts');
        thePromise.then(
            (response) => {
                setPostsList(response.data)
            }, (err) => {
                console.log(err);
            }
        );
    },[]); 
   
    return (
        <div>
            <h1> List of all Posts</h1>
            <ul> 
                {
                    postList.map(p => <li key={p.id}>{p.title}</li>)
                }
           </ul>
        </div>
    )
}

export default UseEffectComponent