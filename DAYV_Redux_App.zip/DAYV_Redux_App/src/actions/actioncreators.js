const INCREMENT_LIKES = 'INCREMENT_LIKES';
const DELETE_PRODUCT = 'DELETE_PRODUCT';
const ADD_PRODUCT = 'ADD_PRODUCT';
const DELETE_POST = 'DELETE_POST';

export function IncrementLikes(theId){
    return {type:INCREMENT_LIKES,theId};
}
export function DeleteProduct(){
    return {type:DELETE_PRODUCT};
}
export function AddProduct(){
    return {type:ADD_PRODUCT};
}
export function DeletePost(){
    return {type:DELETE_POST};
}