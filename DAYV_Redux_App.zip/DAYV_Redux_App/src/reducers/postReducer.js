export function posts(defStore=[],action){
    switch (action.type) {
        case "DELETE_POST":
          console.log("Within Posts Reducer :: DELETE_POST");
          return defStore; // new Store !              
        default:           
         return defStore;
      }
}