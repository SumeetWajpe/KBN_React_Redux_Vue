import { combineReducers } from "redux";
import {posts} from './postReducer';
import {products} from './productReducer';
var rootReducer = combineReducers({
    posts,products
});
export default rootReducer;