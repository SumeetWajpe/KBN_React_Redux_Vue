var theIndex ;
export function products(defStore = [], action) {
  switch (action.type) {
    case "INCREMENT_LIKES":
      console.log("Within Products Reducer :: INCREMENT_LIKES");
      
    theIndex = defStore.findIndex(p => p.id == action.theId);

      return [
            ...defStore.slice(0,theIndex),
            {...defStore[theIndex],likes:defStore[theIndex].likes+1},
            ...defStore.slice(theIndex+1)
      ]; // new Store
    case "DELETE_PRODUCT":
      console.log("Within Products Reducer :: DELETE_PRODUCT");
      return defStore; // new Store !      
    default:       
     return defStore;
  }
}

