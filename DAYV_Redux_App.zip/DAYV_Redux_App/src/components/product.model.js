export default class ProductModel{
    constructor(id=0,name="",price=0,rating=0,quantity=0,likes=0,imageUrl=""){
        this.id= id;
        this.name = name;
        this.price = price;  
        this.rating = rating;       
        this.quantity = quantity;       
        this.likes = likes;       
        this.imageUrl = imageUrl;       
    }
}