import React from 'react';
import logo from './logo.svg';
import './App.css';
import ListOfProducts from './listofproducts.component';
import { BrowserRouter, Link, Switch, Route, Redirect } from 'react-router-dom';

function App(props) {  
  return (
    <BrowserRouter>
    
    <nav className="navbar navbar-inverse">
        <div className="container-fluid">
          <div className="navbar-header">
            <Link className="navbar-brand" to="/">
              Online Shopping
            </Link>
          </div>
          <ul className="nav navbar-nav">
            <li>
              <Link to="/">Home</Link>
            </li>
                     
          </ul>
        </div>
      </nav>
    <Switch>
        <Route path="/" exact render={(routeprops)=> <ListOfProducts {...routeprops} {...props} />}></Route>
        <Route path="**" render={() => <Redirect to="/" />}></Route>
      </Switch>
    </BrowserRouter>
            
  );
}

export default App;
