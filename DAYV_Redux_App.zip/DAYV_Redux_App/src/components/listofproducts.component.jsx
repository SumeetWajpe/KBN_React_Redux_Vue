import React from 'react';
import Product from './product.component';

export default class ListOfProducts extends React.Component {
    constructor(props) {
        super(props);
    }   
    render() {
        var productsToBeDisplayed = this.props.allproducts.map(
            p => <Product 
            productdetails={p} 
            key={p.id}
            {...this.props}
             />
        );
        return <div>
            <div className="jumbotron">
                <h1> Online Shopping</h1>
            </div>
            <div className="row">
                {productsToBeDisplayed}
            </div>
        </div>
    }
}