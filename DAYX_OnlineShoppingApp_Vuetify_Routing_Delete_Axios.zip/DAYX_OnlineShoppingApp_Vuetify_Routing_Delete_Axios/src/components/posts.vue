<template>
    <div>
        <h1 class="display-2">All Posts</h1>
        <v-alert
      border="left"
      colored-border
      color="green"     
      elevation="2"
      v-for="post in allposts"
      :key="post.id"
    >
     <!-- <router-link to="`/postdetails/${}`"> {{post.title}} </router-link> -->
     <router-link :to="{ name:'postdetails' , params:{id: post.id}}"> {{post.title}} </router-link>

    </v-alert>
    </div>
</template>

<script>
import axios from 'axios';

    export default {
        name :'Posts',
        data(){
            return {
                allposts:[]
            }
        },
        mounted(){
             axios.get('https://jsonplaceholder.typicode.com/posts')   
             .then(response=> this.allposts = response.data)
        }

    }
</script>

<style scoped>

</style>