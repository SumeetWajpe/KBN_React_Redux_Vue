<template>
    <div>
        <h1> Post Details for {{postid}} </h1>
    </div>
</template>

<script>
    export default {
        name:'PostDetails',
        data(){
            return{
                postid: this.$route.params.id
            }
        }
    }
</script>

<style scoped>

</style>