import React from 'react';

export const Product = (props) => {
    return <div className="col-md-4">
            <div className="ProductStyle">
                <h1>{props.productdetails.name}</h1>
                <img src={props.productdetails.imageUrl}
                    height="200px" width="200px" />
                <h5>Price : {props.productdetails.price}</h5>
                <h5>Rating : {props.productdetails.rating}</h5>
                <h5>Quantity : {props.productdetails.quantity}</h5>
                <button className="btn btn-primary" 
                onClick={()=>props.IncrementLikes(props.productdetails.id)}>
                    <span className="glyphicon glyphicon-thumbs-up">
                    </span>
                    {props.productdetails.likes}
                </button>
                <button className="btn btn-danger" 
                onClick={()=>props.DeleteProduct(props.productdetails.id)}>
                    <span className="glyphicon glyphicon-trash">
                    </span>
                </button>
            </div>
        </div>
}

export default Product;