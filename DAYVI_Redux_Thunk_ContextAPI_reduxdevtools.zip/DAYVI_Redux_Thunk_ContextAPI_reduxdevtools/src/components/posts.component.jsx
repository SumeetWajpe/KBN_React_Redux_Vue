import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import PostDetails from './postdetails.component';
import axios from 'axios';

function PostsComponent(props) {   
        useEffect(()=>{            
          props.FetchAllPostsAsync();
        },[]);

        var listsofpoststobcreated = props.allposts.map(p => 
        <li key={p.id}>
            <Link to={"/postdetails/" + p.id}>{p.title}
            </Link> {' '}
            <button className="btn btn-danger" onClick={()=>props.DeletePost(p.id)}>
                <span className="glyphicon glyphicon-trash">

                </span>
            </button>
        </li>);
        return <div>
            <div className="jumbotron">
                <h1> All Posts </h1>
            </div>            
            <ul>                
                {listsofpoststobcreated}
            </ul>
        </div>
    }
export default PostsComponent;