import React, { useEffect, useState, useContext } from "react";
import { PostsContext } from "./App";

// export const PostDetails = (props) => {
    
//     const allPostsProps = useContext(PostsContext); // consumer | Hook()
//     const {match:{params}} = props;
//     var singlepost = allPostsProps.allposts.find(p=>p.id == params.id);

//       return(
//         <div>
//             <div className="jumbotron">
//                 <h1> Post Details </h1>               
//             </div>   
//                 <h3>Id : { singlepost.id}</h3>
//                 <h3>User Id : { singlepost.userId}</h3>
//                 <h3>Title : { singlepost.title}</h3>
//                 <h3>Body : { singlepost.body}</h3>         
//         </div>
//     )
// }

//<Context.Consumer>
export const PostDetails = (props) => {
    const {match:{params}} = props;
    return (
        <PostsContext.Consumer>
            {
                allPostsPropsCtx =>{                    
                    var singlepost = allPostsPropsCtx.allposts.find(p=>p.id == params.id);
                    console.log(allPostsPropsCtx.allposts.length);
                    console.log(allPostsPropsCtx);
                    return  <div>
                                 <div className="jumbotron">
                                     <h1> Post Details </h1>               
                                 </div>   
                                     <h3>Id : { singlepost.id}</h3>
                                     <h3>User Id : { singlepost.userId}</h3>
                                     <h3>Title : { singlepost.title}</h3>
                                     <h3>Body : { singlepost.body}</h3>         
                             </div>
                }
            }
        </PostsContext.Consumer>
    )
   
}

export default PostDetails;