import React, { useState } from 'react'

export const AddNewProductComponent = (props) => {

    var [newProduct, setNewProduct] = useState(
        {
            id: 0,
            name: "",
            quantity: 0,
            price: 0,
            rating: 0,
            likes: 0,
            imageUrl: ""
        });

    return (
        <form onSubmit={
            (e)=>{
                e.preventDefault(); // prevents the form from being submitted !
                console.log(newProduct);
            }
        }>
            Id : <input type="number"
                value={newProduct.id}
                className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, id: +(e.target.value) })}
            />
            Name : <input type="text"
                value={newProduct.name}
                className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
            />
             Quantity : <input type="text"
                value={newProduct.quantity}
                className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, quantity: +(e.target.value) })}
            />
            Price : <input type="text"
                value={newProduct.price}
                className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, price: +(e.target.value) })}
            />
             Rating : <input type="text"
                value={newProduct.rating}
                className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, rating: +(e.target.value) })}
            />
             Likes : <input type="text"
                value={newProduct.likes}
                className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, likes: +(e.target.value) })}
            />

            Image Url : <input type="text"
                value={newProduct.imageUrl}
                className="form-control"
                onChange={(e) => setNewProduct({ ...newProduct, imageUrl: e.target.value })}
            />

            <button className="btn btn-success">
                <span className="glyphicon glyphicon-plus-sign">

                </span>
            </button>
        </form>

    )
}

export default AddNewProductComponent