var theIndex;
export function posts(defStore=[],action){
    switch (action.type) {
        case "DELETE_POST":
          theIndex = defStore.findIndex((p) => p.id == action.theId);

      return [...defStore.slice(0, theIndex), ...defStore.slice(theIndex + 1)]; // new Store           
        case "FETCH_ALL_POSTS":
          //console.log('Within Posts FETCH_ALL_POSTS !');
          return action.data; // response from  the server !
          default:           
         return defStore;
      }
}