<template>
  <div id="app">    
        <Course v-for="c in courses" 
        :course-details="c" :key="c.name"></Course>
        
   
  </div>
</template>

<script>
//import HelloWorld from './components/HelloWorld.vue'
import Course from './components/course.component.vue';
// local registration
export default {
  name: 'App',
  components: {    
     Course
  },data(){
    return{
       courses: [{ name: 'React', price: 8000 },
                { name: 'Redux', price: 4000 },
                { name: 'Typescript', price: 6000 },
                { name: 'Bootstrap', price: 4000 }]
            }
    }
  }
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
