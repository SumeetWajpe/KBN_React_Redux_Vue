<template>
<div class="courseStyle">
    <h1>{{courseDetails.name}} </h1>
    <strong>{{courseDetails.price}}</strong>
</div>
</template>

<script>
export default {
    name: 'Course',
    // data(){
    //     return{
    //         coursename:'Vue'
    //     }
    // },
    props: {
        courseDetails: {    
            type: Object,
            required:true,
            default:function(){
                return {
                    name:'Angular',price:9000
                }
            }          
        }
    }
}
</script>

<style scoped>
    .courseStyle{
        border:1px solid red;
        border-radius: 5px;
        margin: 10px;
        padding: 10px;
    }
</style>
